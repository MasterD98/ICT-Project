/*
 * stepper motor_01.c
 *
 * Created: 12/4/2021 7:50:28 AM
 * Author : Amal Shalinda
 */ 

#define F_CPU 8000000UL		
#include <avr/io.h>		
#include <util/delay.h>		

int main(void)
{
	int period;
	DDRC = 0xF0;
	period = 10;		
	while (1)
	{
		/* Rotate  clockwise */
		for(int i=0;i<15;i++) //108 degree cutting arm
		{
			PORTC = 0x30;
			_delay_ms(period);
			PORTC = 0x20;
			_delay_ms(period);
			PORTC = 0x60;
			_delay_ms(period);
			PORTC = 0x40;
			_delay_ms(period);
			PORTC = 0xc0;
			_delay_ms(period);
			PORTC = 0x80;
			_delay_ms(period);
			PORTC = 0x90;
			_delay_ms(period);
			PORTC = 0x10;
			_delay_ms(period);
			PORTC = 0x30;
			_delay_ms(period);
		}
		_delay_ms(10);
		
		/* Rotate  Anticlockwise  */
		for(int i=0;i<15;i++)
		{
			PORTC = 0x30;
			_delay_ms(period);
			PORTC = 0x90;
			_delay_ms(period);
			PORTC = 0xc0;
			_delay_ms(period);
			PORTC = 0x60;
			_delay_ms(period);
			PORTC = 0x30;
			_delay_ms(period);
		}
		
		_delay_ms(10);
	}
}



