/*
 * DC.c
 *
 * Created: 5/12/2022 11:07:13 AM
 * Author : asus
 */ 

#define F_CPU 16000000UL
#include <avr/io.h>

int main()
{
	int speedMode = 0; //get speedMode as user input
	int speed;

      if(speedMode==1)
		{
			speed=255;
		}
		else
		{
			speed=80;
		}
	

	DDRB = 0xFF;
	DDRB |= (1 << PB3);
	TCCR0  = (1 << WGM00) | (1 << WGM01) | (1 << COM01) | (1 << CS00);
	OCR0 = speed;

	while (1)
	{
		PORTB |= 0b00000010;
	}
}

