/*
 * proximity sensor.c
 *
 * Created: 12/12/2021 4:07:06 PM
 * Author : user
 */ 
#define F_CPU 8000000UL
#include <avr/io.h>
int main()
{
	PORTC = 0x00;
	DDRC  = 0x20;

	while (1)
	{
		if(PIND & 1<<PD7){
			PORTC |= 0b00100000;
			}else{
			PORTC &= 0b11011111;
		}
	}
}




